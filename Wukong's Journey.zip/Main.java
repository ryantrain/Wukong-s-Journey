import processing.core.PApplet;

public class Main {
    public static void main(String[] args) {
        String[] processingsArgs = {"Sketch"};
        Sketch Sketch = new Sketch();
        PApplet.runSketch(processingsArgs, Sketch);
    }
}