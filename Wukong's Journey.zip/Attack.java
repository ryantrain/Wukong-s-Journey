import processing.core.PApplet;
import processing.core.PImage;

/**
 * The Attack class represents an attack animation in the game.
 * It handles the rendering, movement, and collision detection of the attack.
 */
public class Attack {
    private PImage[] attackFrames = new PImage[4]; // Array to store attack animation frames
    private PApplet app; // Reference to the PApplet object for rendering and utilities
    private int currentFrame = 0; // Index of the current animation frame
    private int frameDelay = 5; // Delay between animation frames
    private int frameCounter = 0; // Counter to control animation timing
    private int x, y; // Position of the attack
    private boolean isFlipped; // Flag to indicate if the attack is flipped (facing left)
    private boolean isActive; // Flag to indicate if the attack is active
    private static int count = 0; // Static counter to track the number of enemies defeated
    private boolean gameComplete = false; // Flag to indicate if the game is complete

    /**
     * Constructor for the Attack class.
     *
     * @param app       The PApplet object used for rendering and utilities.
     * @param x         The x-coordinate of the attack's starting position.
     * @param y         The y-coordinate of the attack's starting position.
     * @param isFlipped Whether the attack is flipped (facing left).
     */
    public Attack(PApplet app, int x, int y, boolean isFlipped) {
        this.app = app;
        this.x = x;
        this.y = y;
        this.isFlipped = isFlipped;
        this.isActive = true;

        // Load attack frames
        for (int i = 0; i < attackFrames.length; i++) {
            attackFrames[i] = app.loadImage("attack-" + (i + 1) + ".png");
        }
    }

    /**
     * Updates the attack's position and animation.
     */
    public void update() {
        // Move the attack left or right based on the flip state
        if (isFlipped) {
            x -= 10; // Move left if flipped
        } else {
            x += 10; // Move right if not flipped
        }

        // Update the animation frame
        frameCounter++;
        if (frameCounter >= frameDelay && !isFlipped) {
            currentFrame = (currentFrame + 1) % attackFrames.length; // Cycle through frames
            frameCounter = 0; // Reset counter
        }

        if (frameCounter >= frameDelay + 1 && isFlipped) {
            currentFrame = (currentFrame + 1) % attackFrames.length; // Cycle through frames
            frameCounter = 0; // Reset counter
        }

        // Deactivate the attack after the last frame
        if (currentFrame == attackFrames.length - 1) {
            isActive = false;
        }
    }

    /**
     * Checks for collision between the attack and an enemy.
     *
     * @param enemy The enemy to check for collision with.
     * @return True if a collision is detected, false otherwise.
     */
    public boolean checkCollision(Enemies enemy) {
        if (enemy == null || enemy.isDefeated()) {
            return false; // No collision if the enemy is null or already defeated
        }

        // Calculate the bounding box of the attack
        int attackWidth = attackFrames[currentFrame].width;
        int attackHeight = attackFrames[currentFrame].height;

        // Adjust attack position based on whether it's flipped or not
        int attackLeft = isFlipped ? x + 150 : x - 30;
        int attackRight = isFlipped ? x + 140 : x + 25;
        int attackTop = y;
        int attackBottom = y + attackHeight;

        // Get the bounding box of the enemy
        int enemyLeft = (int) enemy.getX();
        int enemyRight = (int) (enemy.getX() + enemy.getWidth());
        int enemyTop = (int) enemy.getY();
        int enemyBottom = (int) (enemy.getY() + enemy.getHeight());

        // Check for overlap between the bounding boxes
        boolean isCollision = !(attackRight < enemyLeft || attackLeft > enemyRight ||
                attackBottom < enemyTop || attackTop > enemyBottom);

        // Handle collision
        if (isCollision && !enemy.isDefeated()) {
            enemy.setDefeated(true); // Mark the enemy as defeated
            count++; // Increment the count of defeated enemies
            deactivate(); // Deactivate the attack
        }

        return isCollision;
    }

    /**
     * Checks if the attack is active.
     *
     * @return True if the attack is active, false otherwise.
     */
    public boolean isActive() {
        return isActive;
    }

    /**
     * Deactivates the attack.
     */
    public void deactivate() {
        this.isActive = false;
    }

    /**
     * Gets the x-coordinate of the attack.
     *
     * @return The x-coordinate of the attack.
     */
    public int getX() {
        return x;
    }

    /**
     * Gets the y-coordinate of the attack.
     *
     * @return The y-coordinate of the attack.
     */
    public int getY() {
        return y;
    }

    /**
     * Sets the x-coordinate of the attack.
     *
     * @param x The new x-coordinate of the attack.
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * Gets the width of the current attack frame.
     *
     * @return The width of the current attack frame.
     */
    public int getWidth() {
        return attackFrames[currentFrame].width;
    }

    /**
     * Gets the height of the current attack frame.
     *
     * @return The height of the current attack frame.
     */
    public int getHeight() {
        return attackFrames[currentFrame].height;
    }

    /**
     * Gets the current animation frame of the attack.
     *
     * @return The current animation frame as a PImage.
     */
    public PImage getCurrentFrame() {
        return attackFrames[currentFrame];
    }

    /**
     * Gets the count of enemies defeated by attacks.
     *
     * @return The count of enemies defeated.
     */
    public static int getCount() {
        return count;
    }
}