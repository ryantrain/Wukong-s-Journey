import processing.core.PApplet;
import processing.core.PImage;

/**
 * The Peach class represents a collectible peach object in the game.
 * It includes functionality for rendering the peach with a bobbing animation
 * and checking if the peach has been collected by the player (monkey).
 */
public class Peach {
    private PApplet app; // Reference to the PApplet object for rendering and math functions
    private int x, y; // Position of the peach on the screen
    private PImage image; // Image representing the peach
    private float offset; // Offset for the sine wave (ensures each peach bobs differently)
    private float amplitude; // Amplitude of the bobbing motion
    private float frequency; // Frequency of the bobbing motion

    /**
     * Constructor for the Peach class.
     *
     * @param app   The PApplet object used for rendering and calculations.
     * @param x     The x-coordinate of the peach's initial position.
     * @param y     The y-coordinate of the peach's initial position.
     * @param image The image representing the peach.
     */
    public Peach(PApplet app, int x, int y, PImage image) {
        this.app = app;
        this.x = x;
        this.y = y;
        this.image = image;
        this.offset = app.random(0, PApplet.TWO_PI); // Random offset for unique bobbing motion
        this.amplitude = 10; // How far the peach moves up and down
        this.frequency = 0.05f; // How fast the peach bobs
    }

    /**
     * Draws the peach on the screen with a bobbing animation.
     * The y-position of the peach is adjusted using a sine wave to create the bobbing effect.
     */
    public void draw() {
        // Calculate the bobbing effect using a sine wave
        float bobbingY = y + app.sin(app.frameCount * frequency + offset) * amplitude;
        // Draw the peach image at the updated y-position
        app.image(image, x, bobbingY);
    }

    /**
     * Checks if the peach has been collected by the monkey.
     * The collection is determined by the distance between the peach and the monkey.
     *
     * @param monkeyX The x-coordinate of the monkey's position.
     * @param monkeyY The y-coordinate of the monkey's position.
     * @return True if the peach is close enough to the monkey to be collected, false otherwise.
     */
    public boolean isCollected(float monkeyX, float monkeyY) {
        // Calculate the distance between the peach and the monkey
        float distance = app.dist(x, y, monkeyX, monkeyY + 80); // Adjust for monkey's height
        // Return true if the distance is within the collection range
        return distance < 50;
    }
}