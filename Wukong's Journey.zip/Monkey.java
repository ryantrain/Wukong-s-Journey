import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * The Monkey class represents the player-controlled character in the game.
 * It extends the Character class and adds functionality for movement, attacking,
 * jumping, and collision detection with enemies.
 */
public class Monkey extends Character {
    private boolean flipped; // Flag to track whether the monkey is facing left or right
    private Attack currentAttack; // The current attack being performed
    private boolean isAttacking; // Flag to track if the monkey is attacking
    private float speed = 3.0f; // Movement speed of the monkey
    private float jumpStrength = -10; // Initial jump strength
    private float ySpeed = 0; // Vertical speed for jumping/falling
    private boolean isJumping = false; // Flag to track if the monkey is jumping
    private static int life = 3; // Number of lives the monkey has
    private PImage heart; // Image representing a life (heart)
    private long lastHitTime = 0; // Timestamp of the last hit
    private final long INVINCIBLE_TIME = 1500; // Duration of invincibility after being hit
    private boolean isInvincible = false; // Flag to track if the monkey is invincible

    /**
     * Constructor for the Monkey class.
     *
     * @param app   The PApplet object used for rendering and utilities.
     * @param x     The initial x-coordinate of the monkey.
     * @param y     The initial y-coordinate of the monkey.
     * @param image The image representing the monkey.
     */
    public Monkey(PApplet app, int x, int y, PImage image) {
        super(app, x, y, image); // Call the superclass constructor
        this.flipped = false; // Initialize as not flipped
        this.isAttacking = false; // Initialize as not attacking
        this.currentAttack = null; // Initialize current attack as null
        this.heart = app.loadImage("data/heart.png"); // Load the heart image
    }

    /**
     * Draws the monkey on the screen, flipping it if necessary, and displays the remaining lives.
     *
     * @param ifStage3 Flag to indicate if the game is in stage 3 (to hide lives display).
     */
    public void draw(boolean ifStage3) {
        app.pushMatrix(); // Save the current transformation matrix
        app.translate(x, y); // Move to the monkey's position

        if (flipped) {
            app.scale(-1, 1); // Flip horizontally
            app.image(image, -image.width, 0); // Draw the flipped image
        } else {
            app.image(image, 0, 0); // Draw the image normally
        }
        app.popMatrix(); // Restore the original transformation matrix

        // Draw hearts to represent lives (if not in stage 3)
        if (!ifStage3) {
            float heartX = app.width - 50; // Start at the top-right corner
            float heartY = 10;
            for (int c = 0; c < life; c++) {
                app.image(heart, heartX - (c * 40), heartY, 30, 30); // Draw each heart
            }
        }

        // Draw the attack if it's active
        if (currentAttack != null && currentAttack.isActive()) {
            app.image(currentAttack.getCurrentFrame(), currentAttack.getX(), currentAttack.getY());
        }
    }

    /**
     * Updates the monkey's state, including attack animation and invincibility timer.
     */
    public void update() {
        // Update the attack animation
        if (isAttacking && currentAttack != null) {
            currentAttack.update();
            if (!currentAttack.isActive()) {
                isAttacking = false; // Reset the attack flag
            }
        }

        // Handle invincibility timer
        if (isInvincible && System.currentTimeMillis() - lastHitTime > INVINCIBLE_TIME) {
            isInvincible = false; // End the invincibility period
        }
    }

    /**
     * Moves the monkey to the left.
     */
    public void moveLeft() {
        x -= speed; // Move left
        flipped = true; // Flip the monkey to face left
    }

    /**
     * Moves the monkey to the right.
     */
    public void moveRight() {
        x += speed; // Move right
        flipped = false; // Flip the monkey to face right
    }

    /**
     * Sets whether the monkey is flipped.
     *
     * @param flipped True to flip the monkey, false otherwise.
     */
    public void setFlipped(boolean flipped) {
        this.flipped = flipped;
    }

    /**
     * Checks if the monkey is jumping.
     *
     * @return True if the monkey is jumping, false otherwise.
     */
    public boolean getJumping() {
        return isJumping;
    }

    /**
     * Checks if the monkey is attacking.
     *
     * @return True if the monkey is attacking, false otherwise.
     */
    public boolean isAttacking() {
        return isAttacking;
    }

    /**
     * Sets the y-coordinate of the monkey.
     *
     * @param y The new y-coordinate of the monkey.
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * Gets the vertical speed of the monkey.
     *
     * @return The vertical speed of the monkey.
     */
    public float getYSpeed() {
        return ySpeed;
    }

    /**
     * Gets the image representing the monkey.
     *
     * @return The monkey's image.
     */
    public PImage getImage() {
        return this.image;
    }

    /**
     * Gets the current attack.
     *
     * @return The current attack.
     */
    public Attack getAttack() {
        return this.currentAttack;
    }

    /**
     * Checks if the monkey is flipped.
     *
     * @return True if the monkey is flipped, false otherwise.
     */
    public boolean isFlipped() {
        return flipped;
    }

    /**
     * Triggers an attack by the monkey.
     */
    public void triggerAttack() {
        attack();
    }

    /**
     * Gets the width of the monkey's image.
     *
     * @return The width of the monkey's image.
     */
    public int getWidth() {
        return image.width;
    }

    /**
     * Initiates an attack by the monkey.
     */
    public void attack() {
        if (currentAttack == null || !currentAttack.isActive()) {
            // Initialize the attack with the current position and direction (flipped)
            currentAttack = new Attack(app, x, y, flipped);
            currentAttack.update(); // Update the attack animation
            isAttacking = true; // Set the attack flag
        }
    }

    /**
     * Checks for collisions between the monkey and enemies.
     *
     * @param enemies The list of enemies to check for collisions.
     */
    public void checkCollisionsWithEnemies(ArrayList<Enemies> enemies) {
        if (isInvincible) return; // Skip collision checks if the monkey is invincible

        Iterator<Enemies> iterator = enemies.iterator();
        while (iterator.hasNext()) {
            Enemies enemy = iterator.next();

            if (enemy.isDefeated()) {
                iterator.remove(); // Remove defeated enemies from the list
                continue; // Skip further processing for this enemy
            }

            // Calculate the distance between the monkey and the enemy
            float distance = PApplet.dist(this.x, this.y, enemy.getX(), enemy.getY());

            // If the distance is below a threshold, the monkey loses a life
            if (distance < 30) { // Set a threshold distance, e.g., 30 pixels
                lastHitTime = System.currentTimeMillis(); // Start the invincibility timer
                isInvincible = true; // Set invincible state to true

                if (enemy.getAttackPower() == 3) {
                    // If it's a super enemy, reduce all life points
                    Monkey.setLife(0);
                } else if (life > 0) {
                    life--; // Reduce life by 1
                }
            }
        }
    }

    /**
     * Gets the current number of lives.
     *
     * @return The current number of lives.
     */
    public static int getLife() {
        return life;
    }

    /**
     * Sets the number of lives.
     *
     * @param lp The new number of lives.
     */
    public static void setLife(int lp) {
        life = lp;
    }
}