import processing.core.PApplet;
import processing.core.PImage;

/**
 * The Enemies class represents an enemy character in the game.
 * It extends the Character class and adds functionality for movement, collision detection,
 * and rendering with flipping based on direction.
 */
public class Enemies extends Character {
    private boolean isDefeated; // Flag to track if the enemy is defeated
    private float speed; // Movement speed of the enemy
    private final float DEFAULTSPEED = 1.0f; // Default movement speed
    private boolean flipped; // Flag to indicate if the enemy is flipped (facing left)
    private int attackPower; // Attack power of the enemy

    /**
     * Constructor for the Enemies class.
     *
     * @param app   The PApplet object used for rendering and utilities.
     * @param x     The initial x-coordinate of the enemy.
     * @param y     The initial y-coordinate of the enemy.
     * @param image The image representing the enemy.
     */
    public Enemies(PApplet app, int x, int y, PImage image) {
        super(app, x, y, image); // Call the superclass constructor
        this.isDefeated = false; // Initialize as not defeated
        this.speed = DEFAULTSPEED; // Set default speed
        this.flipped = false; // Initialize as not flipped
        this.attackPower = 1; // Set default attack power
    }

    /**
     * Constructor for the Enemies class with custom attack power.
     *
     * @param app         The PApplet object used for rendering and utilities.
     * @param x           The initial x-coordinate of the enemy.
     * @param y           The initial y-coordinate of the enemy.
     * @param image       The image representing the enemy.
     * @param attackPower The attack power of the enemy.
     */
    public Enemies(PApplet app, int x, int y, PImage image, int attackPower) {
        this(app, x, y, image); // Call the primary constructor
        this.attackPower = attackPower; // Set custom attack power
    }

    /**
     * Moves the enemy towards Wukong's position.
     *
     * @param wukongX The x-coordinate of Wukong's position.
     */
    public void move(int wukongX) {
        float deltaX = wukongX - this.x; // Difference in X axis
        float distance = Math.abs(deltaX); // Absolute distance

        if (distance != 0) {
            deltaX /= distance; // Normalize X component
        }

        this.x += deltaX * speed; // Move the enemy
        this.flipped = (deltaX < 0); // Flip if moving left
    }

    /**
     * Checks if the enemy is hit by an attack.
     *
     * @param attack The attack to check for collision with.
     */
    public void checkForHit(Attack attack) {
        if (!isDefeated && attack.checkCollision(this)) {
            this.setDefeated(true); // Mark the enemy as defeated if hit
        }
    }

    /**
     * Checks if the enemy is defeated.
     *
     * @return True if the enemy is defeated, false otherwise.
     */
    public boolean isDefeated() {
        return isDefeated;
    }

    @Override
    /**
     * Draws the enemy on the screen, flipping it if necessary.
     */
    public void draw() {
        if (!isDefeated) {
            if (flipped) {
                app.pushMatrix(); // Save the current transformation matrix
                app.translate(x + image.width, y); // Move to the flip origin
                app.scale(-1, 1); // Flip horizontally
                app.image(image, 0, 0); // Draw the flipped image
                app.popMatrix(); // Restore the original transformation matrix
            } else {
                app.image(image, x, y); // Draw the image normally
            }
        }
    }

    /**
     * Sets the defeated status of the enemy.
     *
     * @param defeated True to mark the enemy as defeated, false otherwise.
     */
    public void setDefeated(boolean defeated) {
        this.isDefeated = defeated;
    }

    /**
     * Gets the width of the enemy's image.
     *
     * @return The width of the enemy's image.
     */
    public int getWidth() {
        return image.width;
    }

    /**
     * Gets the height of the enemy's image.
     *
     * @return The height of the enemy's image.
     */
    public int getHeight() {
        return image.height;
    }

    /**
     * Sets the y-coordinate of the enemy.
     *
     * @param y The new y-coordinate of the enemy.
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * Sets the x-coordinate of the enemy.
     *
     * @param x The new x-coordinate of the enemy.
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * Gets the attack power of the enemy.
     *
     * @return The attack power of the enemy.
     */
    public int getAttackPower() {
        return attackPower;
    }
}