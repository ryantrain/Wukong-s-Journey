import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * The SaveData class handles saving and loading game data to/from a file.
 * It manages high scores for different game stages and provides methods to update and retrieve them.
 */
public class SaveData {

    private static final String SAVE_FILE = "data/savefile.txt"; // Path to the save file

    /**
     * Saves the highest scores for a specific save file.
     * Only updates the scores if the new scores are higher than the existing ones.
     *
     * @param saveFileIndex           The index of the save file to update.
     * @param highestMovementScore    The highest score for the movement game.
     * @param highestEnemyKillScore   The highest score for the enemy kill game.
     * @param highestEatingGameScore  The highest score for the eating game.
     */
    public static void save(int saveFileIndex, int highestMovementScore, int highestEnemyKillScore, int highestEatingGameScore) {
        try {
            File file = new File(SAVE_FILE); // Open the save file
            Scanner scanner = new Scanner(file); // Create a scanner to read the file
            StringBuilder newContent = new StringBuilder(); // Store the updated file content
            int currentLine = 0; // Track the current line number

            // Read all lines and update the corresponding save line
            while (scanner.hasNext()) {
                String line = scanner.nextLine(); // Read the next line
                String[] data = line.split(","); // Split the line into parts
                if (currentLine == saveFileIndex) {
                    // Parse existing scores
                    int existingMovementScore = Integer.parseInt(data[1]); // Existing movement score
                    int existingEnemyKillScore = Integer.parseInt(data[2]); // Existing enemy kill score
                    int existingEatingGameScore = Integer.parseInt(data[3]); // Existing eating game score

                    // Only update if the new scores are higher
                    if (highestMovementScore > existingMovementScore) {
                        data[1] = String.valueOf(highestMovementScore); // Update movement score
                    }
                    if (highestEnemyKillScore > existingEnemyKillScore) {
                        data[2] = String.valueOf(highestEnemyKillScore); // Update enemy kill score
                    }
                    if (highestEatingGameScore > existingEatingGameScore) {
                        data[3] = String.valueOf(highestEatingGameScore); // Update eating game score
                    }
                }
                newContent.append(String.join(",", data)).append("\n"); // Rebuild the line and add to new content
                currentLine++; // Move to the next line
            }
            scanner.close(); // Close the scanner

            // Rewrite the file with updated data
            try (FileWriter writer = new FileWriter(file)) {
                writer.write(newContent.toString()); // Write the updated content to the file
            }

        } catch (IOException | NumberFormatException e) {
            e.printStackTrace(); // Handle file or parsing errors
        }
    }

    /**
     * Loads the scores for a specific save file.
     *
     * @param saveFileIndex The index of the save file to load.
     * @return An array containing the scores: [Movement Game Score, Enemy Kill Game Score, Eating Game Score].
     */
    public static int[] load(int saveFileIndex) {
        int[] scores = new int[3]; // Array to store the scores
        try {
            File file = new File(SAVE_FILE); // Open the save file
            Scanner scanner = new Scanner(file); // Create a scanner to read the file
            int currentLine = 1; // Track the current line number

            // Find the line corresponding to the save file index
            while (scanner.hasNext()) {
                String line = scanner.nextLine(); // Read the next line
                if (currentLine == saveFileIndex) {
                    String[] data = line.split(","); // Split the line into parts
                    if (data.length >= 4) { // Ensure there are enough elements to parse
                        scores[0] = Integer.parseInt(data[1]); // Load movement game score
                        scores[1] = Integer.parseInt(data[2]); // Load enemy kill game score
                        scores[2] = Integer.parseInt(data[3]); // Load eating game score
                    }
                    break; // Exit the loop after finding the correct line
                }
                currentLine++; // Move to the next line
            }
            scanner.close(); // Close the scanner
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace(); // Handle file or parsing errors
        }
        return scores; // Return the loaded scores
    }

    /**
     * Returns the number of save files available.
     *
     * @return The number of save files.
     */
    public static int getNumSaves() {
        int numSaves = 0; // Counter for the number of save files
        try {
            File file = new File(SAVE_FILE); // Open the save file
            Scanner scanner = new Scanner(file); // Create a scanner to read the file

            // Count the number of lines in the file
            while (scanner.hasNextLine()) {
                scanner.nextLine(); // Move to the next line
                numSaves++; // Increment the counter
            }
            scanner.close(); // Close the scanner
        } catch (IOException e) {
            e.printStackTrace(); // Handle file errors
        }
        return numSaves; // Return the number of save files
    }
}