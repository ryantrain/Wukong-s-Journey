import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;

/**
 * The EatingGame class represents a mini-game where the player collects peaches.
 * It handles spawning, updating, and drawing peaches, as well as tracking the player's score.
 */
public class EatingGame {
    private PApplet app; // Reference to the PApplet object for rendering and utilities
    private ArrayList<Peach> peaches; // List to store active peaches
    private PImage peachImage; // Image representing a peach
    private int spawnInterval; // Time interval between peach spawns
    private long lastSpawnTime; // Timestamp of the last peach spawn
    private int monkeyY; // Y-coordinate of the monkey (used for collision detection)
    private int score; // Player's current score
    private File file = new File("data/coords.txt"); // File containing spawn coordinates
    private ArrayList<int[]> spawnCoords; // List to store spawn coordinates
    private int x, y; // Temporary variables for storing coordinates

    /**
     * Constructor for the EatingGame class.
     *
     * @param app       The PApplet object used for rendering and utilities.
     * @param peachImage The image representing a peach.
     * @param monkeyY   The y-coordinate of the monkey (used for collision detection).
     */
    public EatingGame(PApplet app, PImage peachImage, int monkeyY) {
        this.app = app;
        this.peachImage = peachImage;
        this.monkeyY = monkeyY + 75; // Adjust for the monkey's height
        this.peaches = new ArrayList<>(); // Initialize the list of peaches
        this.spawnInterval = 500; // Set the spawn interval to 500ms
        this.lastSpawnTime = 0; // Initialize the last spawn time
        this.score = 0; // Initialize the score
        this.spawnCoords = new ArrayList<>(); // Initialize the list of spawn coordinates

        loadCoordinates(file); // Load spawn coordinates from the file
    }

    /**
     * Updates the game state, including spawning peaches and checking for collisions.
     *
     * @param monkeyX The x-coordinate of the monkey.
     * @param monkeyY The y-coordinate of the monkey.
     */
    public void update(float monkeyX, float monkeyY) {
        // Spawn a new peach if the spawn interval has passed
        if (app.millis() - lastSpawnTime >= spawnInterval) {
            spawnPeach();
            lastSpawnTime = app.millis();
        }

        // Update and draw each peach, and check for collisions
        for (int i = peaches.size() - 1; i >= 0; i--) {
            Peach peach = peaches.get(i);
            peach.draw(); // Draw the peach
            if (peach.isCollected(monkeyX, monkeyY)) { // Check if the peach is collected
                peaches.remove(i); // Remove the collected peach
                score++; // Increase the score
            }
        }
    }

    /**
     * Draws all active peaches on the screen.
     */
    public void draw() {
        for (Peach peach : peaches) {
            peach.draw(); // Draw each peach
        }
    }

    /**
     * Spawns a new peach at a random spawn coordinate.
     */
    private void spawnPeach() {
        // Select a random spawn coordinate from the list
        int[] coord = spawnCoords.get(app.floor(app.random(spawnCoords.size())));
        x = coord[0]; // Set the x-coordinate
        y = coord[1]; // Set the y-coordinate
        peaches.add(new Peach(app, x, y, peachImage)); // Create and add a new peach
    }

    /**
     * Gets the player's current score.
     *
     * @return The player's score.
     */
    public int getScore() {
        return score;
    }

    /**
     * Loads spawn coordinates from a file.
     *
     * @param file The file containing spawn coordinates.
     */
    private void loadCoordinates(File file) {
        try (Scanner scanner = new Scanner(file)) {
            // Read each line of the file
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] coords = line.split(","); // Split the line into x and y coordinates
                x = Integer.parseInt(coords[0].trim()); // Parse the x-coordinate
                y = Integer.parseInt(coords[1].trim()); // Parse the y-coordinate
                spawnCoords.add(new int[] { x, y }); // Add the coordinates to the list
            }
        } catch (IOException e) {
            e.printStackTrace(); // Handle file reading errors
        }
    }
}