import processing.core.PApplet;
import processing.core.PImage;

/**
 * The Character class represents a generic character in the game.
 * It provides basic functionality for movement, rendering, and position management.
 */
public class Character {
    protected PApplet app; // Reference to the PApplet object for rendering and utilities
    protected PImage image; // Image representing the character
    protected int x; // X-coordinate of the character's position
    protected int y; // Y-coordinate of the character's position
    protected int speed; // Movement speed of the character

    /**
     * Constructor for the Character class.
     *
     * @param app   The PApplet object used for rendering and utilities.
     * @param x     The initial x-coordinate of the character.
     * @param y     The initial y-coordinate of the character.
     * @param image The image representing the character.
     */
    public Character(PApplet app, int x, int y, PImage image) {
        this.app = app;
        this.x = x;
        this.y = y;
        this.image = image;
    }

    /**
     * Moves the character by a specified amount in the x and y directions.
     *
     * @param dx The amount to move in the x-direction.
     * @param dy The amount to move in the y-direction.
     */
    public void move(int dx, int dy) {
        this.x += dx; // Update the x-coordinate
        this.y += dy; // Update the y-coordinate
    }

    /**
     * Draws the character on the screen at its current position.
     */
    public void draw() {
        app.image(image, x, y); // Draw the character's image
    }

    /**
     * Gets the x-coordinate of the character.
     *
     * @return The x-coordinate of the character.
     */
    public int getX() {
        return x;
    }

    /**
     * Gets the y-coordinate of the character.
     *
     * @return The y-coordinate of the character.
     */
    public int getY() {
        return y;
    }

    /**
     * Sets the image representing the character.
     *
     * @param image The new image for the character.
     */
    public void setImage(PImage image) {
        this.image = image;
    }
}