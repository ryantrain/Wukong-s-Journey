import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;

/**
 * The main Sketch class that extends PApplet and serves as the entry point for the game.
 * This class handles the game's lifecycle, including setup, drawing, and user input.
 */
public class Sketch extends PApplet {
    // Game objects
    private Monkey monkey; // The player-controlled monkey
    private Enemies enemy; // The enemy object
    private DanceGame dancegame; // The dance mini-game
    private EatingGame eatingGame; // The eating mini-game

    // Movement flags
    private boolean moveLeft = false; // Flag for moving left
    private boolean moveRight = false; // Flag for moving right
    private boolean moveUp = false; // Flag for moving up
    private boolean moveDown = false; // Flag for moving down

    // Animation-related variables
    private int speed = 2; // Movement speed of the monkey
    private PImage[] idleFrames; // Array of idle animation frames
    private PImage[] attackFrames; // Array of attack animation frames
    private PImage[] runFrames; // Array of running animation frames
    private PImage[] jumpFrames; // Array of jumping animation frames
    private PImage superenemyImage; // Image for the super enemy
    private ArrayList<Enemies> enemies; // List of active enemies
    private int currentFrame = 0; // Index of the current animation frame
    private int frameDelay = 15; // Delay between animation frames
    private int frameCounter = 0; // Counter to control animation timing
    private final int DEFAULTFRAMEDELAY = 15; // Default delay between frames

    // Game state flags
    private boolean titlescreen = true; // Flag for the title screen
    private boolean savescreen1 = false; // Flag for the first save screen
    private boolean savescreen2 = false; // Flag for the second save screen
    private boolean stage1 = false; // Flag for stage 1 (Dance Game)
    private boolean stage2 = false; // Flag for stage 2 (Combat Game)
    private boolean stage3 = false; // Flag for stage 3 (Eating Game)
    private boolean ending = false; // Flag for the ending scene
    private boolean cutscene1 = false; // Flag for cutscene 1
    private boolean cutscene2 = false; // Flag for cutscene 2
    private boolean cutscene3 = false; // Flag for cutscene 3
    private boolean loading = false; // Flag for loading state
    private boolean loading2 = false; // Flag for secondary loading state

    // UI and visual effects
    private float alpha = 0; // Alpha value for fading effects
    private boolean fadingIn = true; // Flag for fading in or out

    // Physics and movement
    private float ySpeed = 0; // Vertical speed for jumping
    private float gravity = 0.3f; // Gravity affecting the monkey
    private boolean isJumping = false; // Flag for jumping state
    private float jumpStrength = -12; // Initial jump strength

    // Attack-related variables
    private boolean isAttacking = false; // Flag for attacking state
    private Attack currentAttack; // The current attack instance

    // Enemy spawning and movement
    private int spawnSide; // Side from which the enemy spawns (1 for left, -1 for right)
    private float enemySpeed = 2; // Speed of the enemy
    private boolean enemyActive = false; // Flag for active enemy
    private int enemyDirection; // Direction of the enemy (1 for right, -1 for left)
    private float enemyTargetX; // Target X position for the enemy
    private float enemyTargetY; // Target Y position for the enemy
    private int spawnInterval = 3000; // Interval between enemy spawns (3 seconds)
    private long lastSpawnTime = 0; // Timestamp of the last enemy spawn
    private long lastSuperEnemyTime = 0; // Timestamp of the last super enemy spawn
    private static final int SUPER_ENEMY_INTERVAL = 10000; // Interval between super enemy spawns (10 seconds)

    // Input handling
    private String input = ""; // Input string for dance game

    // Timing and delays
    private int endTime = 0; // Timestamp for ending scene
    private int startTime = 0; // Timestamp for starting the game
    private int loadTime = 0; // Timestamp for loading state
    private int loadTime2 = 0; // Timestamp for secondary loading state
    private int loadTime3 = 0; // Timestamp for tertiary loading state
    private boolean startCount = false; // Flag for starting countdown
    private int timer = 60; // Countdown timer for stage 3
    private int countdownStartTime = 0; // Timestamp for countdown start
    private boolean timerStarted = false; // Flag for countdown state

    // Images and assets
    private PImage titlebackground; // Background image for the title screen
    private PImage background2; // Background image for stage 2
    private PImage background3; // Background image for stage 3
    private PImage scene1; // Image for cutscene 1
    private PImage scene2; // Image for cutscene 2
    private PImage scene3; // Image for cutscene 3

    // Save file management
    private static int saveFileIndex; // Index of the selected save file
    private int selectedSaveIndex = 0; // Currently selected save file index
    private int[] scores; // Array to store high scores

    // Stage-specific flags
    private boolean ifStage3; // Flag for stage 3-specific logic

    /**
     * Settings method to define the size of the game window.
     */
    public void settings() {
        size(600, 600); // Set the window size to 600x600 pixels
    }

    /**
     * Setup method to initialize game assets and variables.
     */
    public void setup() {
        frameRate(60); // Set the frame rate to 60 FPS
        size(600, 600); // Set the window size
        background(0); // Set the background color to black

        // Load animation frames
        idleFrames = new PImage[4]; // Initialize array for idle frames
        attackFrames = new PImage[4]; // Initialize array for attack frames
        runFrames = new PImage[5]; // Initialize array for run frames
        jumpFrames = new PImage[2]; // Initialize array for jump frames

        // Load game assets
        PImage enemyImage = loadImage("enemy.png"); // Load enemy image
        PImage peachImage = loadImage("data/peach.png"); // Load peach image
        titlebackground = loadImage("data/titlescreen.png"); // Load title screen background
        background2 = loadImage("data/bg2.png"); // Load stage 2 background
        background3 = loadImage("data/bg3.png"); // Load stage 3 background
        scene1 = loadImage("data/cutscene1.png"); // Load cutscene 1 image
        scene2 = loadImage("data/cutscene2.png"); // Load cutscene 2 image
        scene3 = loadImage("data/cutscene3.png"); // Load cutscene 3 image
        superenemyImage = loadImage("data/superenemy.png"); // Load super enemy image

        // Load animation frames
        for (int i = 0; i < idleFrames.length; i++) {
            idleFrames[i] = loadImage("idle-" + (i + 1) + ".png"); // Load idle frames
        }
        for (int i = 0; i < attackFrames.length; i++) {
            attackFrames[i] = loadImage("attack-" + (i + 1) + ".png"); // Load attack frames
        }
        for (int i = 0; i < runFrames.length; i++) {
            runFrames[i] = loadImage("run-" + (i + 1) + ".png"); // Load run frames
        }
        for (int i = 0; i < jumpFrames.length; i++) {
            jumpFrames[i] = loadImage("jump-" + (i + 1) + ".png"); // Load jump frames
        }

        // Initialize game objects
        monkey = new Monkey(this, 20, 450, idleFrames[0]); // Create the monkey object
        enemies = new ArrayList<Enemies>(); // Initialize the list of enemies
        eatingGame = new EatingGame(this, peachImage, 450); // Create the eating game object
    }

    /**
     * The main draw method that handles rendering and game logic.
     */
    public void draw() {
        if (titlescreen) {
            // Display title screen
            background(titlebackground); // Draw the title screen background
            textSize(60); // Set text size
            fill(255); // Set text color to white
            text("Wukong's Journey", 25, 60); // Draw the game title

            // Fade in and out the "Press Enter to START" text
            if (fadingIn) {
                alpha += 3; // Increase alpha for fade-in effect
                if (alpha >= 255) {
                    fadingIn = false; // Stop fading in when fully visible
                }
            } else {
                alpha -= 3; // Decrease alpha for fade-out effect
                if (alpha <= 0) {
                    fadingIn = true; // Start fading in when fully invisible
                }
            }

            if (startTime > 0 && millis() - startTime > 200) {
                titlescreen = false; // Exit title screen after 200ms
                savescreen1 = true; // Move to the first save screen
            }

            // Draw the "Press Enter to START" text with fading effect
            textSize(40); // Set text size
            fill(255, 255, 255, alpha); // Set text color with alpha
            text("Press Enter to START", 80, 550); // Draw the text
        }

        if (!titlescreen && savescreen1) {
            // Display save file selection screen
            background(0); // Set background to black
            textSize(30); // Set text size
            fill(255); // Set text color to white
            text("Choose a save file", 180, 30); // Draw the prompt

            textSize(20); // Set text size for save files
            int numSaveFiles = SaveData.getNumSaves(); // Get the number of save files
            for (int i = 0; i < numSaveFiles; i++) {
                int[] saveData = SaveData.load(i); // Load save data for each file
                String saveText = "Save File " + (i + 1); // Create save file text
                text(saveText, 30, 60 + (i * 40)); // Draw the save file text
            }

            // Highlight the selected save file
            fill(255, 255, 0); // Set text color to yellow
            textSize(30); // Set text size
            text("<——", 160, 62 + (selectedSaveIndex * 40)); // Draw the selection arrow

            if (loadTime > 0 && millis() - loadTime > 200) {
                savescreen1 = false; // Exit the first save screen
                savescreen2 = true; // Move to the second save screen
                loading = false; // Reset loading flag
            }
        }

        if (!titlescreen && savescreen2) {
            // Display save file details and confirm selection
            background(0); // Set background to black
            textSize(30); // Set text size
            fill(255); // Set text color to white
            text("Game 1 Highscore: " + scores[0], 20, 100); // Draw Game 1 high score
            text("Game 2 Highscore: " + scores[1], 20, 140); // Draw Game 2 high score
            text("Game 3 Highscore: " + scores[2], 20, 180); // Draw Game 3 high score
            text("Use selected save file?", 100, 40); // Draw the prompt
            text("Press ENTER to continue", 110, 300); // Draw the continue prompt
            text("Press BACKSPACE to go back", 75, 360); // Draw the back prompt

            if (loadTime3 > 0 && millis() - loadTime3 > 200) {
                savescreen2 = false; // Exit the second save screen
                cutscene1 = true; // Move to cutscene 1
            }
        }

        if (!titlescreen && cutscene1) {
            // Display cutscene 1
            background(scene1); // Draw the cutscene 1 background
        }

        if (!titlescreen && stage1) {
            // Run stage 1 (Dance Game)
            dancegame.draw(); // Draw the dance game
            if (dancegame.isGameComplete()) {
                stage1 = false; // Exit stage 1
                cutscene2 = true; // Move to cutscene 2
            }
        }

        if (!titlescreen && cutscene2) {
            // Display cutscene 2
            background(scene2); // Draw the cutscene 2 background
        }

        if (loading) stage2 = true; // Move to stage 2 if loading is true

        if (!titlescreen && stage2) {
            // Run stage 2 (Combat Game)
            background(background2); // Draw the stage 2 background
            textSize(100); // Set text size
            fill(255, 255, 255); // Set text color to white
            text(currentAttack.getCount(), 270, 100); // Draw the attack count

            if (monkey.getLife() == 0 && startCount == false) {
                loadTime2 = millis(); // Start the countdown timer
                startCount = true; // Set the start count flag
            }

            if (loadTime2 > 0 && millis() - loadTime2 < 3000) {
                background(0); // Set background to black
                textSize(30); // Set text size
                text("Game 2 Completed!", 150, 300); // Draw the completion message
            }
            if (loadTime2 > 0 && millis() - loadTime2 > 3000) {
                loading = false; // Reset loading flag
                loading2 = true; // Set secondary loading flag
                cutscene3 = true; // Move to cutscene 3
            }

            if (!startCount) {
                // Spawn enemies and super enemies
                if (millis() - lastSpawnTime >= spawnInterval) {
                    spawnEnemy(); // Spawn a regular enemy
                    lastSpawnTime = millis(); // Update the last spawn time
                }
                if (millis() - lastSuperEnemyTime >= SUPER_ENEMY_INTERVAL) {
                    spawnSuperEnemy(); // Spawn a super enemy
                    lastSuperEnemyTime = millis(); // Update the last super enemy spawn time
                }

                if (!enemyActive) {
                    spawnEnemy(); // Spawn an enemy if none are active
                } else {
                    for (Enemies enemy : enemies) {
                        if (!enemy.isDefeated() && enemy != null) {
                            enemy.move((int) monkey.getX()); // Move the enemy
                            enemy.draw(); // Draw the enemy

                            if (currentAttack != null && currentAttack.isActive() && !isJumping) {
                                enemy.checkForHit(currentAttack); // Check for attack collision
                            }
                        }
                    }
                }

                if (isAttacking && currentAttack != null) {
                    currentAttack.update(); // Update the attack animation
                    monkey.setImage(currentAttack.getCurrentFrame()); // Set the monkey's image to the attack frame

                    for (Enemies enemy : enemies) {
                        if (!enemy.isDefeated()) {
                            enemy.move((int) monkey.getX()); // Move the enemy
                            enemy.draw(); // Draw the enemy

                            if (currentAttack != null && currentAttack.isActive()) {
                                float distance = dist(monkey.getX(), monkey.getY(), enemy.getX(), enemy.getY());
                                if (distance < 100 && currentAttack.checkCollision(enemy)) {
                                    enemy.setDefeated(true); // Defeat the enemy if hit
                                }
                            }
                        }
                    }

                    if (!currentAttack.isActive()) {
                        isAttacking = false; // Reset the attack flag
                        currentAttack = null; // Clear the current attack
                    }
                }

                // Handle animations and movement
                animating(); // Update the monkey's animation

                if (isJumping) {
                    ySpeed += gravity; // Apply gravity
                    monkey.move(0, (int) ySpeed); // Move the monkey vertically
                }

                if (monkey.getY() >= 450) {
                    monkey.setY(450); // Reset the monkey's Y position to the ground
                    isJumping = false; // Stop jumping
                    ySpeed = 0; // Reset vertical speed
                }

                if (monkey != null) {
                    if (moveLeft) {
                        monkey.moveLeft(); // Move the monkey left
                    }
                    if (moveRight) {
                        monkey.moveRight(); // Move the monkey right
                    }

                    monkey.update(); // Update the monkey's position and animation
                    monkey.checkCollisionsWithEnemies(enemies); // Check for collisions with enemies
                    monkey.draw(ifStage3); // Draw the monkey
                }

                if (isAttacking && currentAttack != null) {
                    currentAttack.update(); // Update the attack animation
                    monkey.setImage(currentAttack.getCurrentFrame()); // Set the monkey's image to the attack frame

                    if (!currentAttack.isActive()) {
                        isAttacking = false; // Reset the attack flag
                        currentAttack = null; // Clear the current attack
                    }
                }

                if (currentAttack != null && currentAttack.isActive() && enemy != null && enemyActive) {
                    if (currentAttack.checkCollision(enemy)) {
                        enemy.setDefeated(true); // Defeat the enemy if hit
                        enemyActive = false; // Reset the enemy active flag
                    }
                }
            }
        }

        if (!titlescreen && cutscene3) {
            // Display cutscene 3
            background(scene3); // Draw the cutscene 3 background
        }

        if (!titlescreen && stage3) {
            // Run stage 3 (Eating Game)
            background(background3); // Draw the stage 3 background
            textSize(40); // Set text size
            animating(); // Update the monkey's animation
            fill(255, 255, 255); // Set text color to white
            text("Score: " + eatingGame.getScore(), 0, 40); // Draw the score
            isAttacking = false; // Disable attacks in stage 3
            textSize(60); // Set text size
            text(timer, 250, 60); // Draw the countdown timer

            eatingGame.update(monkey.getX(), monkey.getY()); // Update the eating game
            ifStage3 = true; // Enable stage 3-specific logic

            if (!timerStarted) {
                countdownStartTime = millis(); // Start the countdown timer
                timerStarted = true; // Set the timer started flag
            }

            if (millis() - countdownStartTime >= 1000) {
                countdownStartTime = millis(); // Reset the countdown start time
                timer--; // Decrease the timer by 1 second
            }

            if (loading2) cutscene3 = false; // Exit cutscene 3 if loading2 is true
            if (timer <= 0) {
                stage3 = false; // Exit stage 3
                ending = true; // Move to the ending scene
            }

            // Handle monkey movement and drawing
            if (monkey != null) {
                if (moveLeft) {
                    monkey.moveLeft(); // Move the monkey left
                    monkey.setFlipped(true); // Flip the monkey's image
                }
                if (moveRight) {
                    monkey.moveRight(); // Move the monkey right
                    monkey.setFlipped(false); // Unflip the monkey's image
                }

                if (isJumping) {
                    ySpeed += gravity; // Apply gravity
                    monkey.move(0, (int) ySpeed); // Move the monkey vertically
                }

                if (monkey.getY() >= 450) {
                    monkey.setY(450); // Reset the monkey's Y position to the ground
                    isJumping = false; // Stop jumping
                    ySpeed = 0; // Reset vertical speed
                }

                monkey.update(); // Update the monkey's position and animation
                monkey.draw(ifStage3); // Draw the monkey
            }
        }

        if (!titlescreen && ending) {
            // Display ending screen
            if (endTime == 0) {
                loadTime2 = 0; // Reset the loading timer
                endTime = millis(); // Start the ending timer
            }

            if (millis() - endTime < 3000) {
                stage2 = false; // Exit stage 2
                stage1 = false; // Exit stage 1
                stage3 = false; // Exit stage 3
                cutscene1 = false; // Exit cutscene 1
                cutscene2 = false; // Exit cutscene 2
                cutscene3 = false; // Exit cutscene 3
                background(0); // Set background to black
                fill(255); // Set text color to white
                textSize(50); // Set text size
                text("Thank you for playing!", 15, 300); // Draw the ending message
            }

            if (millis() - endTime >= 3000) {
                SaveData.save(saveFileIndex - 1, dancegame.getCurrentStage(), currentAttack.getCount(), eatingGame.getScore()); // Save the game data
                exit(); // Exit the game
            }
        }
    }

    /**
     * Handles key press events.
     */
    public void keyPressed() {
        if (titlescreen) {
            if (keyCode == ENTER) {
                startTime = millis(); // Start the game when Enter is pressed
            }
        }

        if (!titlescreen && savescreen1) {
            int numSaveFiles = SaveData.getNumSaves(); // Get the number of save files

            if (keyCode == UP) {
                selectedSaveIndex = (selectedSaveIndex - 1 + numSaveFiles) % numSaveFiles; // Move up in the save file list
            } else if (keyCode == DOWN) {
                selectedSaveIndex = (selectedSaveIndex + 1) % numSaveFiles; // Move down in the save file list
            } else if (keyCode == ENTER) {
                saveFileIndex = selectedSaveIndex + 1; // Select the save file
                scores = SaveData.load(saveFileIndex); // Load the save data
                loadTime = millis(); // Start the loading timer
                
                dancegame = new DanceGame(this, saveFileIndex); // Instantiate class DanceGame class object
                
            }
        }

        if (!titlescreen && savescreen2) {
            if (keyCode == BACKSPACE) {
                loadTime = 0; // Reset the loading timer
                savescreen2 = false; // Exit the second save screen
                savescreen1 = true; // Return to the first save screen
            }

            if (keyCode == ENTER) {
                loadTime3 = millis(); // Start the loading timer
            }
        }

        if (cutscene1) {
            if (keyCode == ENTER) {
                cutscene1 = false; // Exit cutscene 1
                stage1 = true; // Move to stage 1
            }
        }

        if (!titlescreen && stage1) {
            if (keyCode == LEFT) {
                input = "LEFT"; // Set input to LEFT
            }
            if (keyCode == RIGHT) {
                input = "RIGHT"; // Set input to RIGHT
            }
            if (keyCode == UP) {
                input = "UP"; // Set input to UP
            }
            if (keyCode == DOWN) {
                input = "DOWN"; // Set input to DOWN
            }

            if (!input.isEmpty()) {
                dancegame.checkSequence(input); // Check the dance sequence
            }
        }

        if (cutscene2) {
            if (keyCode == ENTER) {
                cutscene2 = false; // Exit cutscene 2
                loading = true; // Set the loading flag
            }
        }

        if (!titlescreen && stage2) {
            if (keyCode == LEFT) {
                moveLeft = true; // Move the monkey left
                monkey.setFlipped(true); // Flip the monkey's image
            }
            if (keyCode == RIGHT) moveRight = true; // Move the monkey right

            if (keyCode == UP && !isJumping) {
                isJumping = true; // Start jumping
                ySpeed = jumpStrength; // Set the jump strength
            }

            if (keyCode == ' ' && !isAttacking) {
                isAttacking = true; // Start attacking
                currentAttack = new Attack(this, monkey.getX(), monkey.getY(), monkey.isFlipped()); // Create a new attack
            }
        }

        if (!titlescreen && cutscene3) {
            if (keyCode == ENTER) {
                loading2 = true; // Set the secondary loading flag
                cutscene3 = false; // Exit cutscene 3
                stage3 = true; // Move to stage 3
            }
        }

        if (!titlescreen && stage3) {
            if (keyCode == LEFT) {
                moveLeft = true; // Move the monkey left
                monkey.setFlipped(true); // Flip the monkey's image
            }
            if (keyCode == RIGHT) {
                moveRight = true; // Move the monkey right
            }

            if (keyCode == UP && !isJumping) {
                isJumping = true; // Start jumping
                ySpeed = jumpStrength; // Set the jump strength
            }
        }
    }

    /**
     * Handles key release events.
     */
    public void keyReleased() {
        if (!titlescreen && stage2) {
            if (keyCode == LEFT) {
                moveLeft = false; // Stop moving left
                monkey.setFlipped(true); // Flip the monkey's image
            }
            if (keyCode == RIGHT) {
                moveRight = false; // Stop moving right
                monkey.setFlipped(false); // Unflip the monkey's image
            }
            if (keyCode == UP) moveUp = false; // Stop moving up
            if (keyCode == DOWN) moveDown = false; // Stop moving down
        }

        if (!titlescreen && stage3) {
            if (keyCode == LEFT) {
                moveLeft = false; // Stop moving left
                monkey.setFlipped(true); // Flip the monkey's image
            }
            if (keyCode == RIGHT) {
                moveRight = false; // Stop moving right
                monkey.setFlipped(false); // Unflip the monkey's image
            }
        }
    }

    /**
     * Spawns a regular enemy at a random side of the screen.
     */
    public void spawnEnemy() {
        spawnSide = (random(1) > 0.5) ? 1 : -1; // Randomly choose left or right side
        enemyActive = true; // Set the enemy active flag

        PImage enemyImage = loadImage("enemy.png"); // Load the enemy image
        int x = (spawnSide == 1) ? -100 : 700; // Set the spawn position
        int y = 450; // Set the Y position to ground level
        Enemies newEnemy = new Enemies(this, x, y, enemyImage); // Create a new enemy

        enemies.add(newEnemy); // Add the enemy to the list
    }

    /**
     * Moves the enemy towards the target position.
     */
    public void moveEnemy() {
        if (enemy.getX() != enemyTargetX) {
            float moveDirection = (enemyTargetX - enemy.getX()) > 0 ? 1.0f : -1.0f; // Determine the move direction
            enemy.setX((int) (enemy.getX() + moveDirection * enemySpeed)); // Move the enemy
        }
    }

    /**
     * Handles animation logic for the monkey.
     */
    public void animating() {
        if (!moveLeft && !moveRight && !moveUp && !moveDown && !isAttacking) {
            frameDelay = DEFAULTFRAMEDELAY; // Set the frame delay
            frameCounter++; // Increment the frame counter
            if (frameCounter >= frameDelay) {
                currentFrame = (currentFrame + 1) % idleFrames.length; // Cycle through idle frames
                monkey.setImage(idleFrames[currentFrame]); // Set the monkey's image
                frameCounter = 0; // Reset the frame counter
            }
        } else if (moveRight && !isAttacking) {
            frameDelay = 1; // Set the frame delay
            frameCounter++; // Increment the frame counter
            if (frameCounter >= frameDelay) {
                currentFrame = (currentFrame + 1) % runFrames.length; // Cycle through run frames
                monkey.setImage(runFrames[currentFrame]); // Set the monkey's image
                frameCounter = 0; // Reset the frame counter
            }
            monkey.setFlipped(false); // Unflip the monkey's image

            if (monkey.getX() > 530) {
                moveRight = false; // Stop moving right at the boundary
            }

        } else if (moveLeft && !isAttacking) {
            frameDelay = 1; // Set the frame delay
            frameCounter++; // Increment the frame counter
            if (frameCounter >= frameDelay) {
                currentFrame = (currentFrame + 1) % runFrames.length; // Cycle through run frames
                monkey.setImage(runFrames[currentFrame]); // Set the monkey's image
                frameCounter = 0; // Reset the frame counter
            }
            monkey.setFlipped(true); // Flip the monkey's image

            if (monkey.getX() < 0) {
                moveLeft = false; // Stop moving left at the boundary
            }
        }

        if (isJumping) {
            if (ySpeed < 0) {
                monkey.setImage(jumpFrames[0]); // Set the monkey's image to the first jump frame
            } else if (ySpeed > 0) {
                monkey.setImage(jumpFrames[1]); // Set the monkey's image to the second jump frame
            }

            if (moveLeft) {
                monkey.setFlipped(true); // Flip the monkey's image
            }
        }
    }

    /**
     * Returns the current save file index.
     *
     * @return The save file index.
     */
    public static int getSaveFileIndex() {
        return saveFileIndex; // Return the save file index
    }

    /**
     * Spawns a super enemy with higher attack power.
     */
    public void spawnSuperEnemy() {
        spawnSide = (random(1) > 0.5) ? 1 : -1; // Randomly choose left or right side
        enemyActive = true; // Set the enemy active flag

        int x = (spawnSide == 1) ? -100 : 700; // Set the spawn position
        int y = 450; // Set the Y position to ground level
        Enemies superEnemy = new Enemies(this, x, y, superenemyImage, 3); // Create a super enemy with attack power 3

        enemies.add(superEnemy); // Add the super enemy to the list
    }
}