import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The DanceGame class represents a dance mini-game where the player must
 * press arrow keys in the correct sequence to complete stages.
 * It includes functionality for rendering the game, checking player input,
 * and managing game progression.
 */
public class DanceGame {
    private PApplet app; // Reference to the PApplet object for rendering and input handling
    private String[][] dancelist; // Array of dance sequences for each stage
    private int currentStage = 0; // Tracks the current stage of the dance game
    private int currentIndex = 0; // Tracks the current step in the dance sequence
    private boolean stageComplete = false; // Flag to indicate if the current stage is complete
    private long messageTime; // Timestamp for when a message is displayed
    private boolean showMessage = false; // Flag to control message visibility
    private final int MESSAGE_DURATION = 2000; // Duration for message display in milliseconds
    private boolean gameComplete = false; // Flag to indicate if the game is complete
    private PImage left; // Image for the left arrow
    private PImage right; // Image for the right arrow
    private PImage up; // Image for the up arrow
    private PImage down; // Image for the down arrow
    private int life = 3; // Number of lives the player has
    private PImage heart; // Image representing a life (heart)
    private int score = 0; // Player's current score
    private int[] scores; // Array to store high scores
    private PImage background; // Background image for the dance game
    private int saveFileIndex;

    /**
     * Constructor for the DanceGame class.
     *
     * @param app The PApplet object used for rendering and input handling.
     */
    public DanceGame(PApplet app, int saveFileIndex) {
        this.app = app;
        this.saveFileIndex = saveFileIndex;
        initializeDanceList(); // Initialize the dance sequences
        left = app.loadImage("data/left.png"); // Load the left arrow image
        right = app.loadImage("data/right.png"); // Load the right arrow image
        up = app.loadImage("data/up.png"); // Load the up arrow image
        down = app.loadImage("data/down.png"); // Load the down arrow image
        heart = app.loadImage("data/heart.png"); // Load the heart image
        background = app.loadImage("data/bg1.png"); // Load the background image
        
    }

    /**
     * Initializes the dance sequences and shuffles them for each stage.
     */
    private void initializeDanceList() {
        // Define the dance sequences for each stage
        dancelist = new String[][] {
            {"LEFT", "RIGHT", "UP", "DOWN", "LEFT", "DOWN"},
            {"RIGHT", "LEFT", "UP", "UP", "DOWN", "DOWN", "RIGHT", "DOWN", "UP", "LEFT", "RIGHT", "DOWN"},
            {"RIGHT", "LEFT", "UP", "UP", "DOWN", "DOWN", "RIGHT", "DOWN", "UP", "LEFT", "RIGHT", "DOWN", "LEFT", "RIGHT", "UP", "DOWN", "UP", "LEFT"}
        };

        shuffleStage(0); // Shuffle the first stage's sequence
        shuffleStage(1); // Shuffle the second stage's sequence
        shuffleStage(2); // Shuffle the third stage's sequence

        scores = SaveData.load(saveFileIndex); // Load high scores from the save file
    }

    /**
     * Shuffles the dance sequence for a specific stage.
     *
     * @param stageIndex The index of the stage to shuffle.
     */
    private void shuffleStage(int stageIndex) {
        List<String> danceStageList = new ArrayList<>();
        for (String step : dancelist[stageIndex]) {
            danceStageList.add(step); // Add each step to the list
        }
        Collections.shuffle(danceStageList); // Shuffle the list
        dancelist[stageIndex] = danceStageList.toArray(new String[0]); // Update the stage with the shuffled list
    }

    /**
     * Draws the dance game on the screen, including the current sequence, score, lives, and messages.
     */
    public void draw() {
        app.background(background); // Draw the background
        app.textSize(20);
        app.fill(255);
        app.text("Press the arrow keys in the displayed order!", 75, 60); // Display instructions
        app.textSize(30);
        app.text("Score: " + score, 10, 580); // Display the current score
        app.text("Highscore: " + scores[0], 375, 580); // Display the high score

        // Display the current dance sequence
        String[] currentSequence = dancelist[currentStage];
        float xPos = 40; // Starting x position for the first arrow
        float yPos = 100; // Starting y position for the first arrow

        for (int i = 0; i < currentSequence.length; i++) {
            String currentDirection = currentSequence[i];
            PImage arrowImage = null;

            // Determine which arrow image to use based on the current step
            switch (currentDirection) {
                case "LEFT":
                    arrowImage = left;
                    break;
                case "RIGHT":
                    arrowImage = right;
                    break;
                case "UP":
                    arrowImage = up;
                    break;
                case "DOWN":
                    arrowImage = down;
                    break;
            }

            // Only draw the arrow if it hasn't been completed yet
            if (i >= currentIndex && arrowImage != null) {
                app.image(arrowImage, xPos, yPos, 75, 75); // Draw the arrow image
            }

            xPos += 90; // Move to the next position
            if (xPos > 510) { // Wrap to the next row if necessary
                xPos = 40;
                yPos += 100;
            }
        }

        // Draw hearts to represent lives
        float heartX = app.width - 50; // Start at the top-right corner
        float heartY = 10;
        for (int c = 0; c < life; c++) {
            app.image(heart, heartX - (c * 40), heartY, 30, 30); // Draw each heart with spacing
        }

        // Show stage complete message if applicable
        if (stageComplete && !showMessage) {
            messageTime = app.millis(); // Start the message timer
            showMessage = true;
        }

        // Display the stage complete message
        if (showMessage) {
            app.background(0); // Clear the screen
            app.text("Stage Complete!", 180, 300); // Display the message
        }

        // Handle game over logic
        if (life == 0 && messageTime == 0) {
            messageTime = app.millis(); // Start the game over timer
            gameComplete = false;
        }

        if (life == 0) {
            app.background(0); // Clear the screen
            app.text("Game 1 Completed!", 150, 300); // Display the game over message
        }

        if (life == 0 && app.millis() - messageTime >= MESSAGE_DURATION) {
            gameComplete = true; // Mark the game as complete
        }

        // Move to the next stage after the message duration
        if (showMessage && app.millis() - messageTime >= MESSAGE_DURATION) {
            advanceStage(); // Advance to the next stage
            showMessage = false;
            messageTime = 0;
        }
    }

    /**
     * Checks if the player's input matches the current step in the dance sequence.
     *
     * @param keyPressed The key pressed by the player.
     */
    public void checkSequence(String keyPressed) {
        // Do not process inputs if a message is being displayed or the game is over
        if (showMessage || life == 0) {
            return;
        }

        // Check if the input matches the current step
        if (recursiveCheck(dancelist[currentStage], keyPressed, currentIndex)) {
            currentIndex++; // Move to the next step
            if (currentIndex == dancelist[currentStage].length) {
                stageComplete = true; // Mark the stage as complete
                score++; // Increase the score
            }
        } else {
            currentIndex = 0; // Reset the sequence if the input is incorrect
            life--; // Decrease the player's life
        }
    }

    /**
     * Recursively checks if the player's input matches the current step in the sequence.
     *
     * @param sequence   The current dance sequence.
     * @param keyPressed The key pressed by the player.
     * @param index      The current index in the sequence.
     * @return True if the input matches the current step, false otherwise.
     */
    private boolean recursiveCheck(String[] sequence, String keyPressed, int index) {
        // Base case: Stop recursion if the input doesn't match or is out of bounds
        if (index >= sequence.length || !keyPressed.equals(sequence[index])) {
            return false;
        }

        // Base case: Input matches the current step
        if (keyPressed.equals(sequence[index])) {
            return true;
        }

        // Recursive case: Check the next step
        return recursiveCheck(sequence, keyPressed, index + 1);
    }

    /**
     * Advances the game to the next stage.
     */
    public void advanceStage() {
        if (life > 0) {
            if (currentStage != 2) {
                currentStage = (currentStage + 1) % dancelist.length; // Move to the next stage
            } else {
                currentStage = 2; // Stay on the final stage
            }
            currentIndex = 0; // Reset the sequence index
            stageComplete = false; // Reset the stage complete flag
            shuffleStage(currentStage); // Shuffle the sequence for the new stage
        }
    }

    /**
     * Returns whether the game is complete.
     *
     * @return True if the game is complete, false otherwise.
     */
    public boolean isGameComplete() {
        return gameComplete;
    }

    /**
     * Returns the current stage of the game.
     *
     * @return The current stage index.
     */
    public int getCurrentStage() {
        return currentStage;
    }
}